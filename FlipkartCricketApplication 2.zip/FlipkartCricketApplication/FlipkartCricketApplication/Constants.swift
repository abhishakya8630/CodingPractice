//
//  Constants.swift
//  FlipkartCricketApplication
//
//  Created by Abhishek on 12/12/20.
//  Copyright © 2020 Abhishek. All rights reserved.
//

import Foundation
enum CricketMatch
{
    static let wicket="Wicket";
}
