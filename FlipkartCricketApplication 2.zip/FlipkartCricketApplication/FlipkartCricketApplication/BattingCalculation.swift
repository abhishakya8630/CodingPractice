//
//  BattingCalculation.swift
//  FlipkartCricketApplication
//
//  Created by Abhishek on 12/12/20.
//  Copyright © 2020 Abhishek. All rights reserved.
//

import Foundation

public class BattingCalculation{
    var  overCount:Int = 0;
     var scoreCount :Int = 0;
    func ballPrediction() -> Int
    {
         let randomInt = Int.random(in: 0..<8)
         return randomInt;
    }
    
   
    
    
}
