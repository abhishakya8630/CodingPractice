//
//  ScoreBoardViewController.swift
//  CricketDemo
//
//  Created by  Abhishek Shakya on 12/12/20.
//  Copyright © 2020 Pinelabs. All rights reserved.
//

import UIKit

class ScoreBoardViewController: UIViewController {
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var teamOneLabel: UILabel!
    @IBOutlet weak var teamOneScoreLabel: UILabel!
    @IBOutlet weak var teamOneOversLabel: UILabel!
    @IBOutlet weak var teamTwoLabel: UILabel!
    @IBOutlet weak var teamTwoScoreLabel: UILabel!
    @IBOutlet weak var teamTwoOversLabel: UILabel!
    @IBOutlet weak var ballOutcomeLabel: UILabel!
    var score = 0;
    var wicket = 0;
    var overBall = 0;
    var countball = 0;
    var selectBatting = true;
    var bothTeamPlayed = 0;
    var objBattingCalculation = BattingCalculation();
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    @IBAction func playNextBall(_ sender: Any) {
        if(selectBatting){
            teamOneLabel.text = "Pakistan(Batting)"
            teamOneLabel.text = "India(Bowling)"
            BattingCalculation();
            if(countball==12||wicket==3)
            {
                AppDelegate.teamOneScore = score;
                teamOneLabel.text = "India(Batting)"
                teamOneLabel.text = "Pakistan(Bowling)"
                score = 0;
                wicket = 0;
                overBall = 0;
                countball = 0;
                selectBatting = false;
                bothTeamPlayed = bothTeamPlayed+1;
                
            }
            
        }
        else
        {
            BattingCalculation();
            if(countball==12||wicket==3)
            {
                AppDelegate.teamTwoScrore = score;
                teamOneLabel.text = "India(Batting)"
                teamOneLabel.text = "Pakistan(Bowling)"
                score = 0;
                wicket = 0;
                overBall = 0;
                countball = 0;
                selectBatting = false;
                bothTeamPlayed = bothTeamPlayed+1;
                
            }
        }
        if(bothTeamPlayed == 2)
        {
            if var secondTeamScore:Int = AppDelegate.teamTwoScrore{
            if var teamOneScore:Int  = AppDelegate.teamOneScore{
            if(secondTeamScore > teamOneScore)
            {
                ballOutcomeLabel.text  = "India Wins"
            }
            else
            {
                ballOutcomeLabel.text  = "Pakistan Wins"
            }
            if(secondTeamScore == teamOneScore)
                {
                    ballOutcomeLabel.text  = "Match Tied"
                }
        }
    }
        
        
    }
}
    
    func BattingCalculation()
    {
        countball = countball+1;
        let ballResult = objBattingCalculation.ballPrediction();
        if(ballResult<7){
            ballOutcomeLabel.text = String(ballResult)
        }
        else
        {
            ballOutcomeLabel.text = CricketMatch.wicket
        }
        if(ballResult == 7){
            teamOneScoreLabel.text =  String(score) + "/" + String(wicket+1)
            wicket += 1;
        }
        else
        {
            teamOneScoreLabel.text =  String(score+ballResult) + "/" + String(wicket)
        }
        if(overBall != 6)
        {
            teamOneOversLabel.text = "0" + "." + String(overBall+1);
            overBall += 1;
        }
        else
        {
            teamOneOversLabel.text = String(overBall/6) + "." + "0";
            overBall = 0;
        }
    }
}
