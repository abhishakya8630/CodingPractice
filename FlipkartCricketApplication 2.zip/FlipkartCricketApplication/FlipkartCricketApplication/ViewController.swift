//
//  ViewController.swift
//  FlipkartCricketApplication
//
//  Created by Abhishek on 12/12/20.
//  Copyright © 2020 Abhishek. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let controller = ScoreBoardViewController.init(nibName: "ScoreBoardViewController", bundle: nil)
               controller.modalPresentationStyle = .overFullScreen
               self.present(controller, animated: true, completion: nil)
      
    }

    
    
}

