//
//  Constants.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

internal struct Constants {
    static let topCornerRadius: CGFloat = 14.0
    static let pullLimitToDismiss: CGFloat = 100.0
    static let pullAmountToBackgroundColor: CGFloat = 1000.0
    static let ViewHeight: CGFloat = 500.0
    static let duration: TimeInterval = 0.4
    
    // MARK:- Set the two card gap
    static let firstCardTopset:CGFloat = 50
    static let topsetBTCards:CGFloat = 60
    
    static let backgroundColor = UIColor.black.withAlphaComponent(0.4)
    static let maximumNumberCardLimitMsg = "You have created maximum number of Cards."
}

enum UIConstants
{
    static let frequency: CGFloat = 5
    static let damping: CGFloat = 1
}

public typealias Completion = () -> ()
