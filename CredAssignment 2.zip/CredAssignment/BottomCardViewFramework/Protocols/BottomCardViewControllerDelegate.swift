//
//  BottomCardViewControllerDelegate.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

@objc public protocol BottomCardViewControllerDelegate: class {
    @objc optional func didFinishAdding(viewController: UIViewController)
    @objc optional func didFinishDismissing(viewController: UIViewController)
    @objc optional func shouldDismiss(viewController: UIViewController) -> Bool
    @objc optional func didFinishDismissingCardController()
}
