//
//  BottomCardViewController.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

// MARK:- You can add multiple bottom card by creating instance of BottomCardViewController class.
// MARK:- For Adding More Cards : Use public AddNewCardController() method and pass the instance of implemented viewController.
// MARK:- For Dismissing Card View : Use public dismissCardViewController() method.

// MARK:- For More Clarification you can check RootViewController Class

// MARK:-I have add one more functionality,You can set the Limit of Cards through maxNumberofCards variable.


import Foundation
import UIKit

class BottomCardViewController: UIViewController {
    
// MARK:- you can set the limit for adding the cards
    public var maxNumberofCards:Int = 5
    
    // MARK:-Array of CardController
    private var arrayCardViewControllers =  [UIViewController]()
    
    private var rootCardViewController: UIViewController?
    private var isShowingCard = false
    private var uiDynamicanimator: UIDynamicAnimator?
    private var dynamicUiItemBehavior: UIDynamicItemBehavior?
    private var uiAttachmentBehavior: [UIAttachmentBehavior] = []
    private var panGesture: UIPanGestureRecognizer!
    private var initialPullPoint = CGPoint.zero
    private var uiCollisionBehavior: UICollisionBehavior?
    private var automaticallyDismiss = true
    private var crossedPulledLimitAmount = true
    public weak var delegate: BottomCardViewControllerDelegate?
    
    override public func viewDidLoad()
    {
        super.viewDidLoad()
        intilizeView()
        initilizationAnimationFields()
        addGesture()
        if let viewController = rootCardViewController
        {
            AddNewCardController(newCardController: viewController)
        }
    }
    
    public override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(false)
    }
    
    public override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
//        arrayCardViewControllers.filter { $0.view.layer.mask != nil }
//            .forEach { $0.view.layer.mask = findingmaskLayer(bound: $0.view.bounds) }
    }
    
    func intilizeView() {
        view.backgroundColor = .clear
    }
    
    // MARK:- Adding new card Controller through this public Method
    public func AddNewCardController(newCardController: UIViewController, size: CGSize = .zero, roundedCorners: Bool = true,isDraggable: Bool = true, bottomBackgroundColor: UIColor? = nil) {
    
        if maxNumberofCards != arrayCardViewControllers.count{
            
            if arrayCardViewControllers.isEmpty { rootCardViewController = newCardController }
            isShowingCard = true
            panGesture.isEnabled = isDraggable
            let containerView = createContainer()
            addChildCard(newCardController: newCardController, containerView: containerView, ViewBackgroundColor: bottomBackgroundColor)
            let previousCards = arrayCardViewControllers.count - 1
            newCardController.view.frame = newControllerFrame(size: size, previousCards: previousCards)
            if roundedCorners {
                newCardController.view.layer.mask = findingmaskLayer(bound: newCardController.view.bounds)
            }
            newCardController.view.addGestureRecognizer(panGesture)
            UIView.animate(withDuration: 0.3) {
                containerView.backgroundColor = Constants.backgroundColor
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1)  {
                let anchorY = self.view.frame.maxY - newCardController.view.bounds.midY
                self.attachCard(aView: newCardController.view, anchorPoint: CGPoint(x: self.view.center.x, y: anchorY))
               // self.uiCollisionBehavior?.addItem(newCardController.view)
            }
          
        }
            
        else
        {
            alert(message: Constants.maximumNumberCardLimitMsg)
        }
    }
    // MARK:- dismissing card Controller through this public Method
    public func dismissCardViewController(completion: Completion? = nil) {
        guard let attachments = uiAttachmentBehavior.last, let item = attachments.items.last,
            let topController = arrayCardViewControllers.last else { return }
        attachments.anchorPoint = CGPoint(x: view.center.x, y: item.center.y + item.bounds.height)
        removeView(controller: topController, animated: true) {
            self.dismissCardViewInOrder()
            completion?()
        }
    }
}

// MARK:- Private Extension
private extension BottomCardViewController
{
    
    // MARK:- Adding Gesture Recognizer
    func addGesture()
    {
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(handleUIGestureRecognizer))
    }
    
    func createContainer() -> UIView
    {
        let View = UIView()
        View.backgroundColor = .clear
        View.frame = view.bounds
        view.addSubview(View)
        return View
    }
    
    // MARK:- Finding previous CardController
    var previousViewController: UIViewController?
    {
        let previousCardIndex = arrayCardViewControllers.count - 2
        guard previousCardIndex >= 0 else { return nil }
        return arrayCardViewControllers[previousCardIndex]
    }
    
    func addChildCard(newCardController: UIViewController, containerView: UIView, ViewBackgroundColor: UIColor?)
    {
        arrayCardViewControllers.append(newCardController)
        addChild(newCardController)
        containerView.addSubview(newCardController.view)
//        addTemporaryBottomView(view: newCardController.view, backgroundColor: ViewBackgroundColor)
        newCardController.didMove(toParent: self)
    }
//
//    func addTemporaryBottomView(view: UIView,backgroundColor: UIColor?)
//    {
//        let View = UIView()
//        View.translatesAutoresizingMaskIntoConstraints = false
//        View.backgroundColor = backgroundColor ?? view.backgroundColor
//        view.addSubview(View)
//    }
    
    func newControllerFrame(size: CGSize, previousCards: Int) -> CGRect
    {
        let viewHeight = view.bounds.height
        let viewWidth = view.bounds.width
        if size != .zero {
            return CGRect(origin: CGPoint(x: 0, y: viewHeight), size: size)
        }
        let topMargin  = Constants.firstCardTopset + (Constants.topsetBTCards * CGFloat(previousCards))
        return CGRect(origin: CGPoint(x: 0, y: viewHeight), size: CGSize(width: viewWidth, height: viewHeight - topMargin))
    }
    
    func findingmaskLayer(bound: CGRect) -> CAShapeLayer?
    {
        let shapelayer = CAShapeLayer()
        shapelayer.frame = bound
        shapelayer.path = UIBezierPath(roundedRect: CGRect(origin: .zero, size: CGSize(width: bound.width, height: bound.height + Constants.ViewHeight)),
            byRoundingCorners: [UIRectCorner.topLeft, UIRectCorner.topRight],
            cornerRadii: CGSize(width: Constants.topCornerRadius,
            height: Constants.topCornerRadius)).cgPath
        
        return shapelayer
    }
    
    func attachCard(aView: UIView,anchorPoint: CGPoint)
    {
        let attachments = UIAttachmentBehavior(item: aView,
                                               attachedToAnchor: anchorPoint)
        attachments.length = 1
        attachments.damping = UIConstants.damping
        attachments.frequency = UIConstants.frequency
        uiDynamicanimator?.addBehavior(attachments)
        uiAttachmentBehavior.append(attachments)
        dynamicUiItemBehavior?.addItem(aView)
    }
    
    // MARK:- Handling Gesture Recognizer
    @objc func handleUIGestureRecognizer(sender: UIPanGestureRecognizer)
    {
        guard let topController = arrayCardViewControllers.last,
            let panView = topController.view,
            let currentAttachmentBehaviour = uiAttachmentBehavior.last,
            let currentDimView = panView.superview else { return }
        let panLocationInWholeView = sender.location(in: view)
        let defaultAnchorPointX = currentAttachmentBehaviour.anchorPoint.x
        let defaultAnchorPointY = self.view.frame.maxY - panView.bounds.midY
        switch sender.state {
        case .possible: return
        case .began:
            initialPullPoint = panLocationInWholeView
        case .changed:
            let newYPosition = defaultAnchorPointY + calculateYPosition(location: panLocationInWholeView.y, initialPulling: initialPullPoint.y)
            currentAttachmentBehaviour.anchorPoint = CGPoint(x: defaultAnchorPointX, y: newYPosition)
            let pulledPercentage = (Constants.pullAmountToBackgroundColor - (panLocationInWholeView.y - initialPullPoint.y)) / Constants.pullAmountToBackgroundColor
            let alphaPercentage = min(0.4, pulledPercentage - 0.6)
            currentDimView.backgroundColor = Constants.backgroundColor.withAlphaComponent(alphaPercentage)
        case .ended, .cancelled, .failed:
            currentAttachmentBehaviour.anchorPoint = CGPoint(x: defaultAnchorPointX, y: defaultAnchorPointY)
            let velocity = CGPoint(x: 0, y: sender.velocity(in: view).y)
            dynamicUiItemBehavior?.addLinearVelocity(velocity, for: panView)
            let shouldDismiss = delegate?.shouldDismiss?(viewController: topController) ?? true
            if sender.translation(in: view).y > Constants.pullLimitToDismiss && shouldDismiss {
                dismissCardViewController()
            } else {
                UIView.animate(withDuration: Constants.duration) {
                    currentDimView.backgroundColor = Constants.backgroundColor
                }
            }
        @unknown default:
            break
            
        }
    }
    
    // MARK:-Calculating Y position
    func calculateYPosition(location: CGFloat, initialPulling: CGFloat) -> CGFloat
    {
        let totalAmountPulled =  location - initialPulling
        if totalAmountPulled < 0 {
            if !crossedPulledLimitAmount { return 0 }
            return totalAmountPulled * log10(1 + initialPullPoint.y/abs(totalAmountPulled))
        } else {
            return totalAmountPulled
        }
    }
    
    // MARK:-Initilizing Animation Fields
    func initilizationAnimationFields()
    {
        uiDynamicanimator = UIDynamicAnimator(referenceView: view)
        uiDynamicanimator?.delegate = self
        dynamicUiItemBehavior = UIDynamicItemBehavior()
        dynamicUiItemBehavior?.allowsRotation = false
        uiCollisionBehavior = UICollisionBehavior()
      //  uiCollisionBehavior?.collisionMode = .boundaries
//        uiCollisionBehavior?.addBoundary(withIdentifier: "leftMargin" as NSCopying, from: CGPoint(x: -0.5, y: 0), to: CGPoint(x: -0.5, y: view.bounds.maxY))
//        uiCollisionBehavior?.addBoundary(withIdentifier: "rightMargin" as NSCopying, from: CGPoint(x: view.bounds.maxX + 0.5, y: 0), to: CGPoint(x: view.bounds.maxX + 0.5, y: view.bounds.maxY))
        if let dynamicItem = dynamicUiItemBehavior ,let _ = uiCollisionBehavior{
            uiDynamicanimator?.addBehavior(dynamicItem)
         //   uiDynamicanimator?.addBehavior(Collision)
        }
    }
    
    // MARK:-Remove View
    func removeView(controller: UIViewController, animated: Bool, completion: @escaping Completion)
    {
        guard let containerView = controller.view.superview else { return }
        UIView.animate(withDuration: animated ? Constants.duration : 0.0, animations: {
            containerView.backgroundColor = UIColor.clear
        })
        { finished in
            completion()
        }
    }
    
    // MARK:-DismissCard
    func dismissCardViewInOrder()
    {
        guard let lastViewController = arrayCardViewControllers.last,
            let currentUiAttachmentBehaviour = uiAttachmentBehavior.last,
            let viewControllerSuperview = lastViewController.view.superview else
        {
            return
        }
        lastViewController.willMove(toParent: nil)
        lastViewController.view.removeFromSuperview()
        viewControllerSuperview.removeFromSuperview()
        lastViewController.removeFromParent()
        arrayCardViewControllers.removeLast()
        uiDynamicanimator?.removeBehavior(currentUiAttachmentBehaviour)
        uiAttachmentBehavior.removeLast()
        uiCollisionBehavior?.removeItem(lastViewController.view)
        dynamicUiItemBehavior?.removeItem(lastViewController.view)
        delegate?.didFinishDismissing?(viewController: lastViewController);
        if let topViewController = arrayCardViewControllers.last
        {
            topViewController.view.addGestureRecognizer(panGesture)
            return
        }
        if let dynamicItem = dynamicUiItemBehavior ,let Collision = uiCollisionBehavior{
            uiDynamicanimator?.removeBehavior(dynamicItem)
            uiDynamicanimator?.removeBehavior(Collision)
        }
        guard automaticallyDismiss else { return }
        dismiss(animated: false, completion: nil)
//        {
//            //self.delegate?.didFinishDismissingCardController?()
//        }
    }
}

extension BottomCardViewController: UIDynamicAnimatorDelegate
{
    public func dynamicAnimatorDidPause(_ animator: UIDynamicAnimator)
    {
        guard isShowingCard, let topViewController = arrayCardViewControllers.last else { return }
        isShowingCard = false
        delegate?.didFinishAdding?(viewController: topViewController)
    }
    
}

