//
//  CardViewControllerDelegate.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit
protocol CardViewDelegate: class {
    func dismiss()
    func AddAnotherCard()
}
