//
//  Constants.swift
//  CredAssignment
//
//  Created by Abhishek on 27/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
enum StringContants
{
    static let identifier = "CardViewImplementedController"

}
