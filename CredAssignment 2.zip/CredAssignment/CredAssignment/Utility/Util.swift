//
//  Util.swift
//  CredAssignment
//
//  Created by Abhishek on 27/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

func getNewController<T:UIViewController>(viewControllerType: T.Type,identifier:String) ->T
{
    return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: identifier)  as! T
}
