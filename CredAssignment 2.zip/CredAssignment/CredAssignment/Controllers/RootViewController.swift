//
//  RootViewController.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import UIKit

class RootViewController: UIViewController
{
    var Svc:CardViewImplementedController?
    
    @IBOutlet weak var btnOpenCardView: UIButton!
    let objBottomCardViewController = BottomCardViewController()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        intilizeView()
    }
    
    // MARK:-intilizeView
    private func intilizeView()
    {
        btnOpenCardView.roundCorners(corners: [.topLeft, .topRight], radius: 20)
    }
    
    // MARK:- adding root view controller
    @IBAction func tap(_ sender: Any)
    {
        objBottomCardViewController.delegate = self
        // MARK:- set the limit
        objBottomCardViewController.maxNumberofCards = 5
        
        guard let vc = Svc
            else {
            return
        }
        
        present(objBottomCardViewController, animated: false, completion: nil)
        
        let root = newController()
        root.delegate = self
        objBottomCardViewController.AddNewCardController(newCardController: root)
        
    }
    fileprivate func newController() -> CardViewImplementedController {
          return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CardViewController") as! CardViewController
      }
}

extension RootViewController: CardViewDelegate
{
    
    func dismiss()
    {
        objBottomCardViewController.dismissCardViewController()
    }
    
    func AddAnotherCard()
    {
        let card = getNewController(viewControllerType:CardViewImplementedController.self, identifier: StringContants.identifier)
        card.delegate = self
        objBottomCardViewController.AddNewCardController(newCardController: card)
    }
    
}

extension RootViewController: BottomCardViewControllerDelegate
{
    
}
