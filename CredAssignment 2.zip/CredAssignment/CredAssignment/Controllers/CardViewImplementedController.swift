//
//  CardViewImplementedController.swift
//  CredAssignment
//
//  Created by Abhishek on 26/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import UIKit
import Foundation

class CardViewImplementedController: UIViewController {
    
    @IBOutlet weak var btnOpenNewCard: UIButton!
    weak var delegate: CardViewDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.gray
    }
    
    override func viewDidAppear(_ animated: Bool) {
        intilizeView()
    }
    
    private func intilizeView()
    {
        btnOpenNewCard.roundCorners(corners: [.topLeft, .topRight], radius: 20)
    }
    
    @IBAction func addNewCard(_ sender: Any) {
        delegate?.AddAnotherCard()
    }
    
    @IBAction func closeButtonPressed(_ sender: Any) {
        delegate?.dismiss()
    }
    
}


