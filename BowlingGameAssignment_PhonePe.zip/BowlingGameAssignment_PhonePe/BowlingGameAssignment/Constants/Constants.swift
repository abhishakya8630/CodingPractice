//
//  Constants.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 16/02/21.
//  Copyright © 2021 Joshua Finch. All rights reserved.
//

import Foundation
import  UIKit

enum Constant{
    static let shotCellReuseIdentifier = "shotCellReuseIdentifier"
    static let player = "Player "
}
