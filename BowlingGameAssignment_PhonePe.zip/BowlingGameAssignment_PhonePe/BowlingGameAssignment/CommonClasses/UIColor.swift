//
//  UIColor.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import UIKit

extension UIColor {
    static let themeTint = UIColor(named: "Theme/Tint")!
    static let themeDark = UIColor(named: "Theme/Dark")!
    static let themeDarkAccent = UIColor(named: "Theme/DarkAccent")!
}
