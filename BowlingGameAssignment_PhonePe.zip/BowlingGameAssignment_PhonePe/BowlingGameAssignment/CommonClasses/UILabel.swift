//
//  UILabel.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import Foundation
import  UIKit
public class CustomLabel{
    public static func createLabel(height:Int) -> UILabel{
        let userName = UILabel.init()
        userName.frame = CGRect(x: 0.0, y: 110.0+CGFloat(80.0*CGFloat(height)), width: UIScreen.main.bounds.size.width - 20.0, height: 50.0)
        userName.text = Constant.player+String(height);
        userName.font = UIFont(name: "verdana", size: 15.0)
        userName.textAlignment = .left
        userName.textColor = .white
        userName.numberOfLines = 0
        return userName;
    }
}

