//
//  TakeShotError.swift
//  BowlingScoreboard
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import Foundation

enum TakeShotError: LocalizedError {

    case alreadyTakenNecessaryShotsInThisFrame
    case invalidShot
    case invalidFrameSetup

    var errorDescription: String? {
        switch self {
        case .alreadyTakenNecessaryShotsInThisFrame:
            return "Already taken necessary shots in this frame"
        case .invalidShot:
            return "Invalid shot"
        case .invalidFrameSetup:
            return "Invalid frame setup"
        }
    }
}
