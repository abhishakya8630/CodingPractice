//
//  AppCoordinator.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import Foundation
import UIKit

final class ApplicationRouter {
    
    private let window: UIWindow
    private var mainCoordinator: MainController?
    
    init() {
        window = UIWindow(frame: UIScreen.main.bounds)
        window.tintColor = .themeTint
        window.backgroundColor = .themeDark
        window.rootViewController = emptyState()
        window.makeKeyAndVisible()
        self.chooseRootViewControllerAsync()
    }
    
    private func chooseRootViewControllerAsync() {
        DispatchQueue.main.async { [unowned self] in
            self.goToMainApp()
        }
    }
    
    private func emptyState() -> UIViewController {
        let viewController = UIViewController()
        viewController.view.backgroundColor = .themeDark
        return viewController
    }
    
    private func goToMainApp() {
        let (mainCoordinator, rootViewController) = createMain()
        self.mainCoordinator = mainCoordinator
        window.rootViewController = rootViewController
    }
    private func createMain() -> (MainController, UIViewController) {
        let mainCoordinator = MainController()
        let viewController = mainCoordinator.startMainControllerConfiguration()
        return (mainCoordinator, viewController)
    }
}
