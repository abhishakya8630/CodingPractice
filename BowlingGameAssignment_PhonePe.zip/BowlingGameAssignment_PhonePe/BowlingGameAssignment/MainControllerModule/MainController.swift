//
//  MainCoordinator.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

final class MainController {
    
    // MARK: - Initialization
    init() {}
    
    // MARK: -
    func startMainControllerConfiguration() -> UIViewController {
        let storyboard = UIStoryboard(name: "Games", bundle: .main)
        let navigationController = storyboard.instantiateInitialViewController() as! UINavigationController
        let gamesViewController = navigationController.viewControllers.first as! PlayerSelectionController
        let gamesViewModel = PlayerSelectionViewModel(startNewGame: { [weak self] in
            self?.configurePlayers(gameSettings: .players, navigationController: navigationController)
        });
        gamesViewController.viewModel = gamesViewModel
        return navigationController
    }
    
    private func configurePlayers(gameSettings: GameSettings, navigationController: UINavigationController) {
        switch gameSettings {
        case .players:
            self.beginNewGame(players:createPlayers(), navigationController: navigationController)
        }
    }
    
    private func beginNewGame(players: [Player], navigationController: UINavigationController) {
        let playerFrames = players.map({ PlayerFrames(player: $0, frames: FrameCollection()!) })
        let game = Game(players: playerFrames)!
        begin(game: game, navigationController: navigationController)
    }
    
    private func begin(game: Game, navigationController: UINavigationController) {
        let storyboard = UIStoryboard(name: "Game", bundle: .main)
        let gameViewController = storyboard.instantiateInitialViewController() as! GameViewController
        let gameViewModel = GameViewModel(game: game)
        gameViewController.viewModel = gameViewModel
        navigationController.pushViewController(gameViewController, animated: true)
    }
    private func createPlayers() -> [Player]
    {
        var players = [Player]()
        for i in 0..<PlayerSelectionController.playerCount{
            let str = Constant.player + String(i)
            let player = Player(name: str)
            players.append(player)
        }
        return players;
    }
    
}
