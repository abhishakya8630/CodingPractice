//
//  GameDelegate.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import Foundation

protocol GameDelegate: class {

    func currentPlayerDidChange()

    func gameFinished()

    func availableShotsDidChange(toShots: [Shot])

    func framesDidChange(toPlayerFrames: [PlayerFrames])
}
