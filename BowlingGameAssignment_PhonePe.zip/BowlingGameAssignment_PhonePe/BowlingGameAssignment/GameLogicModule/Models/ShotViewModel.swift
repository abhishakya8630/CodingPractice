//
//  ShotViewModel.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//


import Foundation

struct ShotViewModel {

    let string: String
    init(shot: Shot) {
        switch shot {
        case .none: string = "-"
        case .one: string = "1"
        case .two: string = "2"
        case .three: string = "3"
        case .four: string = "4"
        case .five: string = "5"
        case .six: string = "6"
        case .seven: string = "7"
        case .eight: string = "8"
        case .nine: string = "9"
        case .spare: string = "/"
        case .strike: string = "X"
        }
    }
}
