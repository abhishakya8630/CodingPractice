//
//  FrameScore.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation

typealias Score = Int

struct FrameScore {

    let frame: Frame
    let frameScore: Score
    let runningTotalScore: Score

    init(frame: Frame, frameScore: Score = 0, runningTotalScore: Score = 0) {
        self.frame = frame
        self.frameScore = frameScore
        self.runningTotalScore = runningTotalScore
    }
}
