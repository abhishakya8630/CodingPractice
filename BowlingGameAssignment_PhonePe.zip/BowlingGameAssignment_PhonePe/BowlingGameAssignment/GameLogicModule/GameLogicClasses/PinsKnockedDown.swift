//
//  PinsKnockedDown.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation

enum PinsKnockedDown: Int {

    /// When the player has knocked down `1...9` pins in a single shot.
    case one = 1, two, three, four, five, six, seven, eight, nine

    /// When the player has knocked down all the pins in a single shot.
    case ten
}
