//
//  FrameHeaderView.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

final class FrameHeaderView: UICollectionReusableView {

    @IBOutlet weak var label: UILabel!

    func configure(text: String) {
        label.text = text
    }
}
