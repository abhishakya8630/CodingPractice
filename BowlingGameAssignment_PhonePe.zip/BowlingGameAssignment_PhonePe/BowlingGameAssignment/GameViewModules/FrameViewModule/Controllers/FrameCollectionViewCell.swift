//
//  FrameCollectionViewCell.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit

final class FrameCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var firstShotView: UIView!
    @IBOutlet weak var secondShotView: UIView!
    @IBOutlet weak var thirdShotView: UIView!
    
    @IBOutlet weak var firstShotLabel: UILabel!
    @IBOutlet weak var secondShotLabel: UILabel!
    @IBOutlet weak var thirdShotLabel: UILabel!
    
    @IBOutlet weak var runningTotalView: UIView!
    @IBOutlet weak var runningTotalLabel: UILabel!
    
    func configure(frame: FrameViewModel) {
        runningTotalLabel.text = frame.runningTotal
        firstShotLabel.text = frame.firstShot
        secondShotLabel.text = frame.secondShot
        thirdShotLabel.text = frame.thirdShot
    }
}
