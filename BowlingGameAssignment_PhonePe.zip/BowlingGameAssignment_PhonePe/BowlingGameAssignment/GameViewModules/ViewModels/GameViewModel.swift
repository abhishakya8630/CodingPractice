//
//  GameViewModel.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import UIKit
import os

class GameViewModel: GameDelegate, TakeShotDelegate {
    
    var playerTwoLabel: UILabel? {
        didSet {
            updatePlayerTwoLabel()
        }
    }

    var turnToShootMessage: UILabel? {
        didSet {
            updateTurnToShootMessage()
        }
    }
    
    var framesCollectionViewController: FramesCollectionViewController? {
        didSet {
            updateFrames()
        }
    }
    
    var availableShotsCollectionViewController: AvailableShotsCollectionViewController? {
        didSet {
            availableShotsCollectionViewController?.takeShotDelegate = self
            updateAvailableShots()
        }
    }
    
    weak var framesCollectionViewHeightConstraint: NSLayoutConstraint? {
        didSet {
            let heightPerPlayer = FramesCollectionViewFlowLayout.Constants.itemSize.height
                + FramesCollectionViewFlowLayout.Constants.frameHeaderSize.height
                + FramesCollectionViewFlowLayout.Constants.lineSpacing
            framesCollectionViewHeightConstraint?.constant = heightPerPlayer * CGFloat(game.players.count) +
                (FramesCollectionViewFlowLayout.Constants.sectionSpacing * CGFloat(game.players.count - 1))
        }
    }
    
    private let game: Game
    static var playerCount:Int?
    init(game: Game) {
        self.game = game
        game.delegate = self
        GameViewModel.playerCount = game.players.count
    }
   
    
    func onViewWillDisappear() {
    }
    
    // MARK: - GameDelegate
    
    func currentPlayerDidChange() {
        updateTurnToShootMessage()
    }
    
    func gameFinished() {
        updateTurnToShootMessage()
    }
    
    func availableShotsDidChange(toShots shots: [Shot]) {
        updateAvailableShots(usingAvailableShots: shots)
    }
    
    func framesDidChange(toPlayerFrames playerFrames: [PlayerFrames]) {
        updateFrames(usingPlayerFrames: playerFrames)
    }
    
    // MARK: - TakeShotDelegate
    
    func take(shot: Shot) {
        do {
            try game.take(shot: shot)
            // TODO: If shot was a spare / strike, show some fanfare and an animation
        } catch let error {
            print(error)
    }
    }

    private func updatePlayerTwoLabel() {
        guard game.players.count > 1 else {
          //  playerTwoLabel?.text = nil
            return
        }
    }
  
    
    private func updateTurnToShootMessage() {
        if let winner = game.winner() {
            
            switch winner {
            case .player(let player, let score):
                turnToShootMessage?.text = "\(String(describing: player.name)) won the game with a score of \(score)"
            case .draw(let score):
                turnToShootMessage?.text = "The game resulted in a draw with a score of \(score)"
            }
        } else {
            turnToShootMessage?.text = "\(String(describing: game.currentPlayer.player.name))'s turn to shoot"
        }
    }
    
    private func updateFrames(usingPlayerFrames playerFrames: [PlayerFrames]? = nil) {
        framesCollectionViewController?.playerFrames = (playerFrames ?? game.players).map({
            $0.frames.frameInfos.map({
                FrameViewModel(frameInfo: $0)
            })
        })
    }
    
    private func updateAvailableShots(usingAvailableShots shots: [Shot]? = nil) {
        availableShotsCollectionViewController?.shots = shots ?? game.availableShots()
    }
}
