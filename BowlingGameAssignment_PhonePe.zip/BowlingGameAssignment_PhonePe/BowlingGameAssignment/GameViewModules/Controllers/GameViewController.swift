//
//  GameViewController.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import UIKit

final class GameViewController: UIViewController {
    
    var viewModel: GameViewModel?
    @IBOutlet weak var playerTwoLabel: UILabel!
    @IBOutlet weak var turnToShootMessage: UILabel!
    @IBOutlet weak var framesCollectionViewHeightConstraint: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createCustomLabel()
        viewModel?.framesCollectionViewHeightConstraint = framesCollectionViewHeightConstraint
        playerTwoLabel.isHidden = true;
        viewModel?.playerTwoLabel = playerTwoLabel
        viewModel?.turnToShootMessage = turnToShootMessage
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        viewModel?.onViewWillDisappear()
        super.viewWillDisappear(animated)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        if let framesCollectionViewController = segue.destination as? FramesCollectionViewController {
            viewModel?.framesCollectionViewController = framesCollectionViewController
        }
        
        if let availableShotsCollectionViewController = segue.destination as? AvailableShotsCollectionViewController {
            viewModel?.availableShotsCollectionViewController = availableShotsCollectionViewController
        }
    }
    
    func createCustomLabel()
    {
        if let playerCount = GameViewModel.playerCount{
            for count in 0..<playerCount{
                self.view.addSubview(CustomLabel.createLabel(height: count))
            }
        }
    }
}
