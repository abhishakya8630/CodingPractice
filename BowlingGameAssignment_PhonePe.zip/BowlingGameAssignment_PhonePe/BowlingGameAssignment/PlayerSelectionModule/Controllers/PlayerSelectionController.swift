//
//  BowlingGameController.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 15/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import UIKit

final class PlayerSelectionController: UIViewController {
    
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var playerCountStepper: UIStepper!
    var viewModel: PlayerSelectionViewModel!
    static var playerCount:Int = 1;
    
    // MARK: - UIViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        playerCountStepper.wraps = true
        playerCountStepper.autorepeat = true
        playerCountStepper.maximumValue = 4
    }
    
    // MARK: -stepperValueChanged
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        countLabel.text = Int(sender.value).description
        
    }
    
    @IBAction func beginNewGame(_ sender: Any) {
        PlayerSelectionController.playerCount = Int(countLabel.text!)!
        viewModel.startNewGame()
    }
}
