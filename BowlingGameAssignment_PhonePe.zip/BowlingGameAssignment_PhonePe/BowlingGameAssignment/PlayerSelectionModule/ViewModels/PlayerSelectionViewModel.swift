//
//  BowlingViewModel.swift
//  BowlingGameAssignment
//
//  Created by Abhishek on 14/02/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
import UIKit
final class PlayerSelectionViewModel {
    typealias StartNewGame = () -> Void
    var startNewGame: StartNewGame
    var playerCount:Int?
    init(startNewGame: @escaping StartNewGame) {
        self.startNewGame = startNewGame
    }
}
