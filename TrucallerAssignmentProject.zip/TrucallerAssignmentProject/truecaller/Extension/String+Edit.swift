//
//  extensions.swift
//  TrucallerAssignmentProject
//
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation

// MARK:- split string function
extension String {
    func split(regex pattern: String) -> [String] {
        
        guard let re = try? NSRegularExpression(pattern: pattern, options: [])
            else { return [] }
        
        let nsString = self as NSString // needed for range compatibility
        let stop = "<SomeStringThatYouDoNotExpectToOccurInSelf>"
        let modifiedString = re.stringByReplacingMatches(
            in: self,
            options: [],
            range: NSRange(location: 0, length: nsString.length),
            withTemplate: stop)
        return modifiedString.components(separatedBy: stop)
    }
}
