//
//  TrueCallerController.swift
//  TrucallerAssignmentProject
//
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import UIKit

class TrueCallerController: UIViewController {
    
    var objLogicLayer:BusinessLogicLayer?
    @IBOutlet weak var btnProcess: UIButton!
    @IBOutlet weak var textView10thCharacter: UITextView!
    @IBOutlet weak var textViewWordCounter: UITextView!
    @IBOutlet weak var textViewEvery10thCharacter: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setBorderColorTextView()
    }
    
    @IBAction func btnProcess(_ sender: Any) {
        ProcessAllTasks()
    }
    
}

private extension TrueCallerController {
    
    // MARK:- set border color on textView
    func setBorderColorTextView()
    {
        
        textView10thCharacter.isEditable = false
        textViewWordCounter.isEditable = false
        textViewEvery10thCharacter.isEditable = false
        btnProcess.layer.cornerRadius = 10
        btnProcess.clipsToBounds = true
        textViewEvery10thCharacter!.layer.borderWidth = 1
        textViewEvery10thCharacter!.layer.borderColor = UIColor.black.cgColor
        textViewWordCounter!.layer.borderWidth = 1
        textViewWordCounter!.layer.borderColor = UIColor.black.cgColor
        textView10thCharacter!.layer.borderWidth = 1
        textView10thCharacter!.layer.borderColor = UIColor.black.cgColor
        textView10thCharacter.text = Constants.beginStatusString
        textViewEvery10thCharacter.text = Constants.beginStatusString;
        textViewWordCounter.text = Constants.beginStatusString;
        
    }
    
    // MARK:- process All task which are given on assignment.
    func ProcessAllTasks()
    {
        objLogicLayer = BusinessLogicLayer();
        btnProcess.isEnabled = false;
        textView10thCharacter.text = Constants.processStatusString
        textViewEvery10thCharacter.text = Constants.processStatusString;
        textViewWordCounter.text = Constants.processStatusString;
        let taskGroup = DispatchGroup();
        taskGroup.enter()
        
        // MARK:- process first task 10th character
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.objLogicLayer?._10thCharacterRequest(completion: { (response) in
                DispatchQueue.main.async {
                    self?.textView10thCharacter.text = response;
                    taskGroup.leave();
                }
            })
        }
        
         // MARK:- process Second task every 10th character
        taskGroup.enter()
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.objLogicLayer?.Every10thCharacterRequest(completion: { (response) in
                DispatchQueue.main.async {
                    self?.textViewEvery10thCharacter.text = response;
                    taskGroup.leave();
                }
            })
        }
        
         // MARK:- process third task word counter
        taskGroup.enter()
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.objLogicLayer?.WordCounterRequest(completion: { (response) in
                DispatchQueue.main.async {
                    self?.textViewWordCounter.text = response;
                    taskGroup.leave();
                }
            })
        }
        
        taskGroup.notify(queue: .main) {[weak self] in
            self?.btnProcess.isEnabled = true;
        }
        
    }
    
    
}


