//
//  LogicServiceLayer.swift
//  TrucallerAssignmentProject
//
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
class BusinessLogicLayer
{
    var apiHandler:ApiHandler?
    init()
    {
        apiHandler = ApiHandler()
    }
    
    // MARK:- Written logic inside this function for getting 10th character
    public func _10thCharacterRequest(completion:  @escaping((String?)->Void))
    {
        var result:String?;
        apiHandler?.getApiData(completion: {(response) in
            if let unwrappedResponseString = response{
                if !unwrappedResponseString.isEmpty
                {
                 
                    // MARK:- String index start from 0th so that is why i inserted 9
                    result = Constants.firstRequestString +  String(unwrappedResponseString[unwrappedResponseString.index(unwrappedResponseString.startIndex, offsetBy:9)]) + "'";
                    completion(result);
                }
            }
        })
    }
    
    
    // MARK:- Written logic inside this function for getting every 10th character
    public func Every10thCharacterRequest(completion:  @escaping((String?)->Void))
    {
        var result:String = "";
        result.append(Constants.secondRequestString);
        apiHandler?.getApiData(completion: {[weak self] (response) in
            if let unwrappedResponseString = response{
                if !unwrappedResponseString.isEmpty
                {
                    var appendingStr = 0;
                    for charCount in 0..<unwrappedResponseString.count {
                        if charCount > 0 && charCount % 10 == 0 {
                            let printCount = charCount-1;
                            result.append(String(unwrappedResponseString[unwrappedResponseString.index(unwrappedResponseString.startIndex, offsetBy: printCount)]))
                            if appendingStr > 0 && appendingStr % 10 == 0 {
                                result.append(" ")
                            }
                            appendingStr = appendingStr+1;
                        }
                    }
                    result.append("'")
                    completion(result);
                }
            }
        })
    }
    
    // MARK:- Written logic inside this function for getting word counter
    public func WordCounterRequest(completion:  @escaping((String?)->Void))
    {
        var result:String = "";
        result.append(Constants.secondRequestString);
        apiHandler?.getApiData(completion: {(response) in
            if let unwrappedResponseString = response{
                if !unwrappedResponseString.isEmpty
                {
                    
                    var dic = Dictionary<String,Int>();
                    if let splitStringArray =  response?.split(regex: "[\\s\\d~`!@#\\$%\\^&\\*\\(\\)\\-\\+\\[\\]\\{\\}\'\"\\\\|/\\?,\\.;:]+"){
                        for var key in splitStringArray {
                            if (key.elementsEqual("")){
                                continue;
                            }
                            key = key.lowercased();
                            if var count =  dic.keys.contains(key) ? dic[key] : 0{
                                count = count+1;
                                dic[key] = count;
                            }
                        }
                        
                        var str = "";
                        str.append("WordCounter Result:\n");
                        for (key,value) in dic {
                            str.append(key)
                            str.append(" : ")
                            str.append(String(value))
                            str.append("\n");
                        }
                        completion(str);
                    }
                }
            }})
    }
    
}
