//  ApiHandler.swift
//  TrucallerAssignmentProject
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.

import Foundation
class ApiHandler {
    typealias JsonDictionay = [String : Any]
    let defaultSession = URLSession(configuration: .default)
    var dataTask: URLSessionDataTask?
    var errorMessage: String = ""
    let serialQueue = DispatchQueue(label: "serialQueue")
    
    // MARK:- this is the Api call for executing the tasks
    public func getApiData(completion:  @escaping((String?)->Void)) {
        dataTask?.cancel()
        let request = URLRequest(url:NSURL.getBaseUrl() as URL)
        serialQueue.async{[weak self] in
            self?.dataTask = self?.defaultSession.dataTask(with: request, completionHandler: { [weak self] data, response, error in
            defer {
                self?.dataTask = nil
            }
            if let error = error {
                self?.errorMessage += "DataTask error: " +
                    error.localizedDescription + "\n"
            }
            else if
                let data = data,
                let response = response as? HTTPURLResponse,
                response.statusCode == 200 {
                let data = data
                do {
                    let responseString:String? = String(decoding: data, as: UTF8.self)
                    completion(responseString)
                }
                catch _ as NSError {
                }
            }
        })
            self?.dataTask?.resume()
    }
    }
}

// MARK:- Here calling of Base Url
private extension NSURL {
    static func getBaseUrl() -> NSURL {
        guard let info = Bundle.main.infoDictionary,
            let urlString = info["Base_url"] as? String,
            let url = NSURL(string: urlString) else {
                fatalError("Cannot get base url from info.plist")
        }
        
        return url
    }
}


