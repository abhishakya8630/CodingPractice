//
//  ApiResponseModel.swift
//  TrucallerAssignmentProject
//
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation
struct ApiResponse
{
    var responseString:String?;
}
public enum APIError:Error{
    case responseProblem
    case decodingproblem
    case responseError
}
