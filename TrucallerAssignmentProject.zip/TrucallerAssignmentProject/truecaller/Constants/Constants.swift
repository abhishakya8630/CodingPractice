//
//  Constants.swift
//  TrucallerAssignmentProject
//
//  Created by Abhishek on 03/01/21.
//  Copyright © 2021 Abhishek. All rights reserved.
//

import Foundation

enum Constants
{
    static let firstRequestString  =  "10th character is '"
    static let secondRequestString = "Every 10th character is '"
    static let processStatusString = "processing..."
    static let beginStatusString = "For the processing please click on submit button."
}
